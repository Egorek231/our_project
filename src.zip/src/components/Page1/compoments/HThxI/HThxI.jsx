import "./HThxI.css"
export default function HThxI(props){
    return <div className="h_t_i">{props.text}</div>
}