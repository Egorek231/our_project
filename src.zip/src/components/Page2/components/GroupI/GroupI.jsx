export default function GroupI(props){
return <div className="groupI">
<div className="group">
<p className="ff">{props.text}</p>
</div>
<div className="group1">
    
<img src={props.images} />

</div>


<div className="group2">
<p className="ff">{props.title}</p>
</div>


</div>

}