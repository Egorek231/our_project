import "../Page3/Page3.css"

function Page3(props) {
  return (
    <>
        <div className="page3">
            <p>
                page3
            </p>
        </div>
    </>
  )
}

export default Page3;